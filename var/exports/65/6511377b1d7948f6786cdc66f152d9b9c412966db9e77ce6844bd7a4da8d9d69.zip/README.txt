TROY — ICT REGISTER EXPORT
==========================

Organisation : Meridian GRC
Generated    : 2026-07-25T06:05:20.622238+00:00
Reporting    : 2026-07-25

EVIDENCE CHAIN HEAD
    39fe09448893d92a14df7961e55efbac9570e7904b8f80f3013713d832e6499e

    This hash covers every monitoring observation recorded up to the
    generation time. Retain it to verify the evidence store independently at
    a later date.

CONTENTS
    RT.*.csv              one file per implemented register template
    labels/RT.*.labels.csv  field code to human label mapping
    manifest.json         full metadata, scope and validation report

VALIDATION
    Result   : PASSED
    Errors   : 0
    Warnings : 0

    Validation covers mandatory-field presence, format rules (LEI, ISO country, ISO date, enumerations) and referential integrity between the implemented templates. It does NOT cover the ESAs' complete published rule set. A clean result here does not guarantee acceptance by a competent authority.

SCOPE
    This export covers the register templates for which Troy holds data. It is not a complete register submission. Fields marked 'Not held by Troy' must be supplied by the filing entity before submission to a competent authority.

    Templates implemented     : RT.01.01, RT.01.02, RT.02.01, RT.02.02, RT.05.01, RT.05.02, RT.06.01, RT.07.01
    Templates not implemented : RT.01.03, RT.02.03, RT.03.01, RT.03.02, RT.03.03, RT.04.01

    Fields sourced from Troy  : 56 of 71
    Requiring manual entry    : 15

GAPS
    Vendors monitored but not registered: 3
    Silicon Valley Bank, Stripe, Fifth Third Bancorp

DISCLAIMER
    This file is generated from a monitoring system. It covers the register templates for which data is held and is not a complete submission package. The filing entity is responsible for completeness and accuracy before submission to a competent authority.
